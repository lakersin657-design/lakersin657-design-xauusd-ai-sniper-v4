# XAUUSD MARKET INTELLIGENCE PRO V4 — AI SNIPER (separate web)

A separate Flask dashboard and signal-analysis service. It does not modify or replace the user's existing V17.1 app or V19 Pine research file.

## Included
- Separate mobile-friendly dashboard and API
- 27 named specialist agents
- V19-inspired M5 scoring rules (score threshold 75, ADX threshold 22, H1 trend confirmation, ATR stop reference 1.4x, 2R target reference)
- M5, M15 and H1 completed-candle checks
- Mandatory two-round external AI debate; missing/failed AI debate blocks confirmation
- Signals-only: no broker connection and no order placement
- SQLite run history
- Background scanner (60-second default)
- Render Blueprint for a separate always-on web service with persistent disk

## Required Render environment variables
- `DASHBOARD_PASSWORD`: private dashboard password (required; HTTP Basic Auth).
- `TWELVEDATA_API_KEY`: Twelve Data key with XAU/USD 5m, 15m and 1h OHLC access.
- `AI_API_KEY`: API key for an OpenAI-compatible chat-completions endpoint.

Optional:
- `AI_API_BASE_URL` (default `https://api.openai.com/v1`)
- `AI_MODEL` (default `gpt-4.1`)
- `MARKET_SYMBOL` (default `XAU/USD`)
- `SCAN_INTERVAL_SECONDS` (default 60)

Never paste passwords or API keys into chat or commit them to Git. Add them in Render Environment settings.

## Local run
```bash
python -m venv .venv
source .venv/bin/activate  # Windows: .venv\\Scripts\\activate
pip install -r requirements.txt
export DASHBOARD_PASSWORD='choose-a-long-password'
export TWELVEDATA_API_KEY='your-key'
export AI_API_KEY='your-key'
python app.py
```
Open http://127.0.0.1:5000

## Separate Render deployment
1. Create a new GitHub repository named `xauusd-ai-sniper-v4`.
2. Upload the contents of this folder to the repository root and push to the default branch.
3. In Render, choose **New + → Blueprint**, connect that repository, and apply its `render.yaml`.
4. Add the three required secret values (`DASHBOARD_PASSWORD`, `TWELVEDATA_API_KEY`, `AI_API_KEY`) in the new service's Environment page.
5. Wait for deploy, then check `/health` and the dashboard.

The Blueprint uses a paid Starter web service and 1 GB persistent disk so its scanner can stay awake and preserve history. Confirm current Render pricing before applying. A free sleeping web service cannot provide continuous monitoring.

## Important limitations
- The 27 agents are a structured council with deterministic specialist checks; only the two-round debate currently calls the external LLM. The `News & Events AI` and `USD & Yields AI` report UNAVAILABLE until dedicated verified feeds are integrated. Missing data is not treated as clearance.
- Broker spread, execution slippage, commissions and actual fills are not available from Twelve Data OHLC. Do not interpret the indicative entry/SL/TP as broker execution prices.
- The Pine V19 strategy is research-only. This Python implementation ports its core scoring concepts, not a byte-for-byte Pine execution clone. Backtest and forward-test before relying on signals.
- A confluence score is not a probability or win-rate estimate. No win rate or profitability is guaranteed.
- The external debate requires an OpenAI-compatible `/chat/completions` endpoint that supports JSON response format. If unavailable, the system returns WAIT.


## Dashboard access
The dashboard is public and does not require a browser password. Keep API keys configured only as Render environment variables; never commit them to GitHub. Public visitors can view the dashboard and its signals. Protect the Render service and API credentials; do not expose secret values in client-side code.
