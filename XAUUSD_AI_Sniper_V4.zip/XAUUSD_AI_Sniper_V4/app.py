import os, time, json, sqlite3, threading, logging, math
from datetime import datetime, timezone
from concurrent.futures import ThreadPoolExecutor
import requests
from flask import Flask, jsonify, render_template, request, Response

logging.basicConfig(level=logging.INFO)
log = logging.getLogger('xauusd-ai-sniper-v4')
app = Flask(__name__)
DB = os.getenv('DATABASE_PATH', 'sniper_v4.db')
SYMBOL = os.getenv('MARKET_SYMBOL', 'XAU/USD')
TWELVE_KEY = os.getenv('TWELVEDATA_API_KEY', '')
AI_BASE = os.getenv('AI_API_BASE_URL', 'https://api.openai.com/v1')
AI_KEY = os.getenv('AI_API_KEY', '')
AI_MODEL = os.getenv('AI_MODEL', 'gpt-4.1')
DASH_USER = os.getenv('DASHBOARD_USERNAME', 'admin')
DASH_PASS = os.getenv('DASHBOARD_PASSWORD', '')
SCAN_SECONDS = max(30, int(os.getenv('SCAN_INTERVAL_SECONDS', '60')))
CACHE = {'at': 0, 'data': None, 'error': None}
LOCK = threading.Lock()
LAST_RESULT = {'at': None, 'status': 'NOT ANALYZED', 'decision': 'WAIT', 'agents': [], 'debate': [], 'signal': None, 'notes': ['Configure a market-data key to begin.']}

AGENTS = [
('Trend Hunter','Reads broad directional structure.'),('Technical Analyst','Checks V19-style EMA, RSI, MACD and ADX confluence.'),('Liquidity Hunter','Looks for stop sweeps and reclaim behavior.'),('Quantitative AI','Evaluates ATR, volatility and statistical regime.'),('Bull Advocate','Builds the strongest evidence-based BUY case.'),('Bear Advocate','Builds the strongest evidence-based SELL case.'),('M5 Bull Close AI','Checks bullish M5 close evidence.'),('M5 Bear Close AI','Checks bearish M5 close evidence.'),('M15 Bull Confirmation','Checks bullish M15 structure.'),('M15 Bear Confirmation','Checks bearish M15 structure.'),('H1 Bull Regime AI','Checks bullish H1 regime.'),('H1 Bear Regime AI','Checks bearish H1 regime.'),('Candle Quality AI','Evaluates body, wick, engulfing and close location.'),('Market Safety AI','Checks feed freshness, spread proxy and abnormal conditions.'),('Supreme Decision AI','Final authority; cannot override hard safety blocks.'),('Data Integrity AI','Checks missing, stale and malformed candles.'),('M5 Candle-Close Auditor','Verifies M5 candle is fully closed.'),('M15 Candle-Close Auditor','Verifies M15 candle is fully closed.'),('H1 Candle-Close Auditor','Verifies H1 candle is fully closed.'),('News & Events AI','Requires configured news feed before claiming event clearance.'),('USD & Yields AI','Requires macro feed; otherwise reports unavailable.'),('Volume & Order-Flow AI','Checks available volume evidence and flags missing volume.'),('Support & Resistance AI','Measures proximity to recent swing levels.'),('Volatility Regime AI','Blocks extreme or unstable volatility.'),('Risk-to-Reward AI','Checks ATR/structure stop and minimum 1:2 reference RR.'),('Manipulation & Anomaly AI','Flags extreme candle ranges and wick anomalies.'),('Red-Team AI','Attempts to invalidate the proposed direction.')]

# Public dashboard: no browser login or DASHBOARD_PASSWORD required.

def db():
    c=sqlite3.connect(DB, timeout=10); c.row_factory=sqlite3.Row; return c

def init_db():
    with db() as c:
        c.execute('CREATE TABLE IF NOT EXISTS runs(id INTEGER PRIMARY KEY, created_at TEXT, decision TEXT, direction TEXT, score INTEGER, payload TEXT)')

def ema(xs, n):
    if len(xs)<n: return None
    v=sum(xs[:n])/n; a=2/(n+1)
    for x in xs[n:]: v=a*x+(1-a)*v
    return v

def rsi(xs, n=14):
    if len(xs)<=n: return None
    ds=[xs[i]-xs[i-1] for i in range(1,len(xs))]
    g=sum(max(x,0) for x in ds[-n:])/n; l=sum(max(-x,0) for x in ds[-n:])/n
    return 100 if l==0 else 100-100/(1+g/l)

def atr(cs, n=14):
    if len(cs)<=n: return None
    trs=[]
    for i in range(1,len(cs)):
        x=cs[i]; p=cs[i-1]
        trs.append(max(x['high']-x['low'],abs(x['high']-p['close']),abs(x['low']-p['close'])))
    return sum(trs[-n:])/n

def adx_approx(cs, n=14):
    if len(cs)<n+2: return None
    plus=[]; minus=[]; trs=[]
    for i in range(1,len(cs)):
        a,b=cs[i],cs[i-1]; up=a['high']-b['high']; dn=b['low']-a['low']
        plus.append(max(up,0) if up>dn else 0); minus.append(max(dn,0) if dn>up else 0)
        trs.append(max(a['high']-a['low'],abs(a['high']-b['close']),abs(a['low']-b['close'])))
    tr=sum(trs[-n:]); p=sum(plus[-n:]); m=sum(minus[-n:])
    if tr<=0: return 0
    pdi=100*p/tr; mdi=100*m/tr
    return 100*abs(pdi-mdi)/max(pdi+mdi,1e-9)

def fetch_tf(tf, outputsize=240):
    if not TWELVE_KEY: raise RuntimeError('TWELVEDATA_API_KEY is not configured')
    r=requests.get('https://api.twelvedata.com/time_series', params={'symbol':SYMBOL,'interval':tf,'outputsize':outputsize,'apikey':TWELVE_KEY,'format':'JSON','timezone':'UTC'}, timeout=12)
    r.raise_for_status(); d=r.json()
    if 'values' not in d: raise RuntimeError(d.get('message','Market data provider returned no candles'))
    out=[]
    for x in reversed(d['values']):
        try:
            t=datetime.strptime(x['datetime'],'%Y-%m-%d %H:%M:%S').replace(tzinfo=timezone.utc).timestamp()
            out.append({'time':t,'open':float(x['open']),'high':float(x['high']),'low':float(x['low']),'close':float(x['close']),'volume':float(x.get('volume') or 0)})
        except Exception: continue
    if len(out)<130: raise RuntimeError(f'Only {len(out)} valid {tf} candles; 130 minimum required')
    return out

def only_closed(cs, seconds):
    now=time.time()
    return [x for x in cs if x['time']+seconds <= now+1]

def v19_features(cs, tf_seconds):
    c=only_closed(cs,tf_seconds)
    if len(c)<130: return {'ok':False,'count':len(c),'direction':'NEUTRAL','score':0,'reason':'Not enough fully closed candles'}
    cl=[x['close'] for x in c]; last,prev=c[-1],c[-2]
    e9,e20,e50,e100=ema(cl,9),ema(cl,20),ema(cl,50),ema(cl,100)
    rv=rsi(cl); av=atr(c); dx=adx_approx(c)
    macd=(ema(cl,12) or 0)-(ema(cl,26) or 0)
    prior=(ema(cl[:-1],12) or 0)-(ema(cl[:-1],26) or 0)
    hi=max(x['high'] for x in c[-21:-1]); lo=min(x['low'] for x in c[-21:-1])
    micro_hi=max(x['high'] for x in c[-7:-1]); micro_lo=min(x['low'] for x in c[-7:-1])
    sweep_lo=min(x['low'] for x in c[-12:-1]); sweep_hi=max(x['high'] for x in c[-12:-1])
    rng=max(last['high']-last['low'],1e-9); body=abs(last['close']-last['open'])/rng; loc=(last['close']-last['low'])/rng
    bull_candle=(last['close']>last['open'] and ((prev['close']<prev['open'] and last['close']>=prev['open'] and last['open']<=prev['close']) or (loc>.72 and body>.40)))
    bear_candle=(last['close']<last['open'] and ((prev['close']>prev['open'] and last['close']<=prev['open'] and last['open']>=prev['close']) or (loc<.28 and body>.40)))
    trend_up=e20>e50>e100 and last['close']>e20; trend_dn=e20<e50<e100 and last['close']<e20
    sweep_up=last['low']<sweep_lo and last['close']>sweep_lo; sweep_dn=last['high']>sweep_hi and last['close']<sweep_hi
    bos_up=last['close']>hi; bos_dn=last['close']<lo
    shift_up=e20<e50 and last['close']>micro_hi; shift_dn=e20>e50 and last['close']<micro_lo
    mom_up=macd>0 and macd>=prior; mom_dn=macd<0 and macd<=prior
    rsi_up=rv is not None and 54<=rv<=68; rsi_dn=rv is not None and 32<=rv<=46
    adx_ok=dx is not None and dx>=22
    up=(25 if trend_up else 0)+(10 if e20>(ema(cl[:-5],20) or e20) else 0)+(10 if mom_up else 0)+(10 if rsi_up else 0)+(20 if bos_up or sweep_up or shift_up else 0)+(15 if bull_candle else 0)+(10 if adx_ok else 0)
    dn=(25 if trend_dn else 0)+(10 if e20<(ema(cl[:-5],20) or e20) else 0)+(10 if mom_dn else 0)+(10 if rsi_dn else 0)+(20 if bos_dn or sweep_dn or shift_dn else 0)+(15 if bear_candle else 0)+(10 if adx_ok else 0)
    atr_pct=(av or 0)/max(last['close'],1e-9); ext=abs(last['close']-e20)/max(av or 0,1e-9)
    vol_ok=av and 0.00015<atr_pct<0.015; chop=(dx or 0)<22; extended=ext>=1.5
    direction='BUY' if up>=75 and up>dn and (bos_up or sweep_up) and bull_candle and last['close']>e9 else 'SELL' if dn>=75 and dn>up and (bos_dn or sweep_dn) and bear_candle and last['close']<e9 else 'NEUTRAL'
    return {'ok':True,'count':len(c),'direction':direction,'buy_score':up,'sell_score':dn,'score':max(up,dn),'close':last['close'],'candle_time':last['time'],'candle_closed':True,'ema20':e20,'ema50':e50,'ema100':e100,'rsi':rv,'adx':dx,'atr':av,'atr_pct':atr_pct,'extension_atr':ext,'vol_ok':bool(vol_ok),'choppy':chop,'extended':extended,'bull_candle':bull_candle,'bear_candle':bear_candle,'bos_bull':bos_up,'bos_bear':bos_dn,'sweep_bull':sweep_up,'sweep_bear':sweep_dn,'shift_bull':shift_up,'shift_bear':shift_dn,'high20':hi,'low20':lo,'last':last,'candles':c}

def ai_debate(direction, feats):
    if not AI_KEY: return {'status':'UNAVAILABLE','rounds':[],'summary':'External AI is not configured. Mandatory AI debate cannot pass; final decision must remain WAIT.'}
    prompt=f'''You are the adversarial debate chair for a signal-only XAUUSD system. Proposed direction: {direction}. Evidence: {json.dumps(feats,default=str)}. Conduct two rounds: (1) strongest bull and bear cases, (2) cross-examination and rebuttal. Identify specific invalidation evidence. Return JSON with keys verdict (PASS/FAIL/UNRESOLVED), bull_case, bear_case, rebuttal, invalidation, summary. Be conservative. Do not invent news or data. PASS only if proposed direction has clear evidence and no unresolved major contradiction.'''
    try:
        resp=requests.post(AI_BASE.rstrip('/')+'/chat/completions',headers={'Authorization':'Bearer '+AI_KEY,'Content-Type':'application/json'},json={'model':AI_MODEL,'temperature':0.1,'response_format':{'type':'json_object'},'messages':[{'role':'system','content':'Return only valid JSON. You are an independent skeptical trading risk analyst.'},{'role':'user','content':prompt}]},timeout=25)
        resp.raise_for_status(); content=resp.json()['choices'][0]['message']['content']; data=json.loads(content)
        return {'status':data.get('verdict','UNRESOLVED'),'rounds':[{'round':1,'title':'Bull vs Bear opening arguments','bull':data.get('bull_case'),'bear':data.get('bear_case')},{'round':2,'title':'Cross-examination and rebuttal','rebuttal':data.get('rebuttal'),'invalidation':data.get('invalidation')}],'summary':data.get('summary','')}
    except Exception as e:
        return {'status':'ERROR','rounds':[],'summary':f'AI debate failed: {type(e).__name__}. Mandatory debate did not pass.'}

def evaluate(frames):
    m5,m15,h1=frames['5min'],frames['15min'],frames['1h']; direction=m5['direction']; score=m5['score']
    results=[]
    def add(name,status,why): results.append({'name':name,'status':status,'reason':why})
    # The council's deterministic specialist checks; macro/news remain unavailable until data integrations exist.
    add('Trend Hunter','PASS' if direction!='NEUTRAL' else 'WAIT',f"M5={direction}; M15={m15['direction']}; H1={h1['direction']}")
    add('Technical Analyst','PASS' if score>=75 else 'WAIT',f"V19 directional confluence {score}/100; threshold 75")
    liq=(m5['sweep_bull'] if direction=='BUY' else m5['sweep_bear']) if direction!='NEUTRAL' else False
    add('Liquidity Hunter','PASS' if liq or (m5['bos_bull'] if direction=='BUY' else m5['bos_bear']) else 'WAIT','Sweep/reclaim or 20-candle breakout required')
    add('Quantitative AI','PASS' if m5['vol_ok'] and not m5['choppy'] and not m5['extended'] else 'VETO','ATR regime, trend strength and extension checks')
    add('Bull Advocate','PASS' if direction=='BUY' else 'CHALLENGE',f"BUY evidence score {m5['buy_score']}/100")
    add('Bear Advocate','PASS' if direction=='SELL' else 'CHALLENGE',f"SELL evidence score {m5['sell_score']}/100")
    for name,tf,want in [('M5 Bull Close AI','5min','BUY'),('M5 Bear Close AI','5min','SELL'),('M15 Bull Confirmation','15min','BUY'),('M15 Bear Confirmation','15min','SELL'),('H1 Bull Regime AI','1h','BUY'),('H1 Bear Regime AI','1h','SELL')]:
        f=frames[tf]; ok=f['direction']==want
        add(name,'PASS' if ok else 'CHALLENGE',f"{tf} closed-candle direction is {f['direction']}; expected {want}")
    add('Candle Quality AI','PASS' if (m5['bull_candle'] if direction=='BUY' else m5['bear_candle']) else 'VETO','V19 engulfing/rejection candle test')
    add('Market Safety AI','UNAVAILABLE','Fresh candles received, but broker spread/quote quality is not available from this OHLC feed')
    # data and candle-close integrity
    for nm,tf in [('Data Integrity AI','5min'),('M5 Candle-Close Auditor','5min'),('M15 Candle-Close Auditor','15min'),('H1 Candle-Close Auditor','1h')]:
        f=frames[tf]; ok=f['ok'] and f['candle_closed'] and time.time()-f['candle_time']<tf_seconds(tf)+120
        add(nm,'PASS' if ok else 'VETO','At least 130 complete candles; most recent analyzed bar is closed and recent' if ok else 'Insufficient, stale or unclosed candle data')
    add('News & Events AI','UNAVAILABLE','No economic-calendar/news provider configured; cannot certify event clearance')
    add('USD & Yields AI','UNAVAILABLE','No live DXY or Treasury-yield feed configured')
    add('Volume & Order-Flow AI','PASS' if m5['last'].get('volume',0)>0 else 'UNAVAILABLE','Volume field present' if m5['last'].get('volume',0)>0 else 'Provider volume unavailable; no order-flow inference made')
    near=max(abs(m5['close']-m5['high20']),abs(m5['close']-m5['low20']))
    add('Support & Resistance AI','PASS' if near>0 else 'WAIT','Recent 20-candle swing levels mapped')
    add('Volatility Regime AI','PASS' if m5['vol_ok'] and not m5['choppy'] else 'VETO','V19 volatility/trend regime filters')
    av=m5['atr'] or 0; px=m5['close']; recent8=m5['candles'][-8:]
    if direction=='BUY':
        swing=min(x['low'] for x in recent8)-0.1*av; stop_dist=max(1.4*av,px-swing)
    else:
        swing=max(x['high'] for x in recent8)+0.1*av; stop_dist=max(1.4*av,swing-px)
    stop_dist=max(stop_dist,0.0001); rr=2.0
    entry=px; stop=px-stop_dist if direction=='BUY' else px+stop_dist; tp=px+2*stop_dist if direction=='BUY' else px-2*stop_dist
    add('Risk-to-Reward AI','PASS' if direction in ('BUY','SELL') and rr>=2 else 'VETO','V19-style wider-of-1.4-ATR or 8-candle swing stop; 2R target reference, not broker execution')
    candle_rng=m5['last']['high']-m5['last']['low']; wick_ratio=(candle_rng-max(0,abs(m5['last']['close']-m5['last']['open'])))/max(candle_rng,1e-9)
    add('Manipulation & Anomaly AI','VETO' if candle_rng>3*av or wick_ratio>.92 else 'PASS','Extreme range or near-total-wick anomaly scan')
    add('Red-Team AI','PASS' if direction!='NEUTRAL' and m15['direction']==direction and h1['direction']==direction else 'VETO','Attempts to invalidate setup: M15 and H1 must agree with M5')
    debate=ai_debate(direction,{'m5':{k:v for k,v in m5.items() if k not in ('last','candles')},'m15':{k:v for k,v in m15.items() if k not in ('last','candles')},'h1':{k:v for k,v in h1.items() if k not in ('last','candles')}}) if direction!='NEUTRAL' else {'status':'NOT_RUN','rounds':[],'summary':'No directional candidate; debate not started.'}
    hard_veto=[x for x in results if x['status']=='VETO']
    required=['M15 Bull Confirmation','H1 Bull Regime AI'] if direction=='BUY' else ['M15 Bear Confirmation','H1 Bear Regime AI'] if direction=='SELL' else []
    if direction=='NEUTRAL': decision='WAIT'
    elif hard_veto or debate['status']!='PASS' or any(next((x['status'] for x in results if x['name']==n),'')!='PASS' for n in required): decision='WAIT'
    else: decision=direction
    sup='PASS' if decision in ('BUY','SELL') else 'WAIT'
    add('Supreme Decision AI',sup,'All hard gates and mandatory debate passed' if sup=='PASS' else 'At least one mandatory gate, debate, or timeframe confirmation failed')
    passed=sum(x['status']=='PASS' for x in results); total=len(AGENTS)
    signal={'direction':direction,'entry':round(entry,2),'stop_loss':round(stop,2),'take_profit_1':round(entry+(stop_dist if direction=='BUY' else -stop_dist),2),'take_profit_2':round(tp,2),'take_profit_3':round(entry+(3*stop_dist if direction=='BUY' else -3*stop_dist),2),'rr_reference':'1:2','score':score} if decision in ('BUY','SELL') else None
    return {'decision':decision,'directional_candidate':direction,'score':score,'agent_passes':passed,'agent_total':total,'agents':results,'debate':debate,'signal':signal,'notes':['Signals only; no broker orders are sent.','News, DXY/yields, and broker spread checks are not connected and cannot be treated as cleared.','V19 thresholds are research rules, not a proven win rate.']}

def tf_seconds(tf): return {'5min':300,'15min':900,'1h':3600}[tf]

def run_analysis():
    global LAST_RESULT
    try:
        with ThreadPoolExecutor(max_workers=3) as ex:
            fs={tf:ex.submit(fetch_tf,tf) for tf in ('5min','15min','1h')}
            raw={tf:fs[tf].result() for tf in fs}
        frames={tf:v19_features(raw[tf],tf_seconds(tf)) for tf in raw}
        if not all(x['ok'] for x in frames.values()): raise RuntimeError('Waiting for sufficient closed candles on all timeframes')
        result=evaluate(frames); result.update({'at':datetime.now(timezone.utc).isoformat(),'symbol':SYMBOL,'frames':{tf:{k:v for k,v in f.items() if k not in ('last','candles')} for tf,f in frames.items()},'market_data':'CONNECTED','ai_provider':'CONNECTED' if AI_KEY else 'NOT CONFIGURED'})
        LAST_RESULT=result
        with db() as c: c.execute('INSERT INTO runs(created_at,decision,direction,score,payload) VALUES(?,?,?,?,?)',(result['at'],result['decision'],result['directional_candidate'],result['score'],json.dumps(result,default=str)))
        return result
    except Exception as e:
        LAST_RESULT={'at':datetime.now(timezone.utc).isoformat(),'status':'ERROR','decision':'WAIT','direction':'NEUTRAL','agents':[],'debate':[],'signal':None,'notes':[str(e)]}
        return LAST_RESULT

@app.route('/')
def home(): return render_template('index.html')
@app.route('/health')
def health(): return jsonify({'ok':True,'version':'V4-27AGENT','market_key_configured':bool(TWELVE_KEY),'ai_key_configured':bool(AI_KEY),'dashboard_access':'public','ai_model':AI_MODEL,'scan_interval_seconds':SCAN_SECONDS,'execution':'signals_only'})
@app.route('/api/status')
def status(): return jsonify(LAST_RESULT)
@app.route('/api/analyze',methods=['POST'])
def analyze_now(): return jsonify(run_analysis())
@app.route('/api/history')
def history():
    with db() as c: rows=c.execute('SELECT id,created_at,decision,direction,score FROM runs ORDER BY id DESC LIMIT 30').fetchall()
    return jsonify([dict(x) for x in rows])
@app.route('/api/settings')
def settings(): return jsonify({'symbol':SYMBOL,'scan_interval_seconds':SCAN_SECONDS,'execution':'signals_only','ai_configured':bool(AI_KEY),'market_data_configured':bool(TWELVE_KEY),'agent_count':len(AGENTS),'agents':[{'name':n,'role':r} for n,r in AGENTS]})

def scanner():
    while True:
        try:
            if TWELVE_KEY: run_analysis()
        except Exception: log.exception('scanner cycle failed')
        time.sleep(SCAN_SECONDS)

init_db()
if os.getenv('DISABLE_SCANNER','0')!='1': threading.Thread(target=scanner,name='sniper-v4-scanner',daemon=True).start()
if __name__=='__main__': app.run(host='0.0.0.0',port=int(os.getenv('PORT','5000')))
